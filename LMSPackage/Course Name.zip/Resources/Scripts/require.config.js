﻿require.config({
    urlArgs: 't=637612609581712033'
});