﻿require.config({
    urlArgs: 't=637612609808688284'
});