﻿require.config({
    urlArgs: 't=637612607898794864'
});