﻿require.config({
    urlArgs: 't=637612608536780732'
});